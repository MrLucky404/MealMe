# NutriPlan Android — Guía de compilación

## Lo que hay en este proyecto

Un proyecto Android Studio listo para compilar que envuelve la app NutriPlan
en un WebView nativo. Incluye:

- localStorage funciona igual que en el navegador (los datos se guardan en el dispositivo)
- Selector de imágenes nativo para las fotos de recetas
- Tema oscuro nativo (status bar y navigation bar oscuros)
- Botón atrás funcional dentro de la app
- Icono de app en verde neón (#c8f55a)

---

## Requisitos previos (instalar una sola vez)

1. **Java JDK 17**
   - Descarga: https://adoptium.net/
   - Instala y apunta JAVA_HOME a la carpeta de instalación

2. **Android Studio** (incluye el SDK de Android)
   - Descarga: https://developer.android.com/studio
   - Durante la instalación acepta instalar el Android SDK

3. **Habilitar "Fuentes desconocidas" en tu Android**
   - Ajustes → Seguridad → Instalar apps desconocidas → Permitir para tu gestor de archivos

---

## Pasos para compilar el APK

### Opción A — Con Android Studio (recomendada, más fácil)

1. Abre Android Studio
2. Selecciona **Open** y elige la carpeta `nutriplan-android`
3. Espera a que Gradle sincronice (primera vez tarda 2-5 min descargando dependencias)
4. En el menú superior: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
5. Cuando termine aparece una notificación abajo. Haz clic en **locate** para abrir la carpeta
6. El APK está en: `app/build/outputs/apk/debug/app-debug.apk`

### Opción B — Desde la terminal (sin Android Studio)

```bash
# En la carpeta nutriplan-android:
# macOS / Linux
./gradlew assembleDebug

# Windows
gradlew.bat assembleDebug

# El APK queda en:
app/build/outputs/apk/debug/app-debug.apk
```

**Nota:** La primera vez descarga Gradle (~150 MB) y el SDK. Necesitas conexión a internet.

---

## Instalar el APK en tu Android

### Por cable USB
```bash
# Con adb (viene con Android Studio):
adb install app/build/outputs/apk/debug/app-debug.apk
```

### Por archivo
1. Copia el `.apk` al teléfono (por cable, WhatsApp, email, Google Drive…)
2. Abre el archivo desde el gestor de archivos del teléfono
3. Acepta instalar

---

## Si quieres actualizar la app web

Simplemente reemplaza el archivo:
```
app/src/main/assets/index.html
```
Y vuelve a compilar con **Build → Build APK(s)**.

---

## Solución de problemas frecuentes

| Error | Solución |
|-------|----------|
| `SDK location not found` | En Android Studio: File → Project Structure → SDK Location |
| `Gradle sync failed` | File → Invalidate Caches → Restart |
| `INSTALL_FAILED_OLDER_SDK` | Tu Android es anterior a 8.0. Cambia `minSdk 26` a `minSdk 21` en `app/build.gradle` |
| La app no instala | Activa "fuentes desconocidas" en Ajustes de seguridad |

---

## Para firmar el APK (distribución)

El APK de debug funciona perfectamente para uso personal.
Si quieres compartirlo o subirlo a Play Store necesitas firmarlo:

1. Build → Generate Signed Bundle / APK
2. Crea un keystore nuevo (guárdalo en lugar seguro)
3. Rellena los datos y genera el APK release firmado
